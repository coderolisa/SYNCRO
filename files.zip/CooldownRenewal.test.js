// test/CooldownRenewal.test.js
// Run with: npx hardhat test
// Requires: @nomicfoundation/hardhat-toolbox

const { expect } = require("chai");
const { ethers } = require("hardhat");
const { time } = require("@nomicfoundation/hardhat-network-helpers");

describe("CooldownRenewal", function () {
  let contract;
  let owner, alice, bob;
  const COOLDOWN = 300; // 5 minutes (seconds)
  const MIN_COOLDOWN = 60;

  beforeEach(async function () {
    [owner, alice, bob] = await ethers.getSigners();
    const Factory = await ethers.getContractFactory("CooldownRenewal");
    contract = await Factory.deploy(COOLDOWN);
    await contract.waitForDeployment();
  });

  // ─── Deployment ────────────────────────────────────────────────────────────

  describe("Deployment", function () {
    it("sets the correct cooldown period", async function () {
      expect(await contract.cooldownPeriod()).to.equal(COOLDOWN);
    });

    it("sets the correct owner", async function () {
      expect(await contract.owner()).to.equal(owner.address);
    });

    it("reverts if cooldown is below minimum (< 60s)", async function () {
      const Factory = await ethers.getContractFactory("CooldownRenewal");
      await expect(Factory.deploy(59))
        .to.be.revertedWithCustomError(contract, "InvalidCooldownPeriod")
        .withArgs(59, MIN_COOLDOWN);
    });

    it("allows deployment at exactly MIN_COOLDOWN (60s)", async function () {
      const Factory = await ethers.getContractFactory("CooldownRenewal");
      const c = await Factory.deploy(MIN_COOLDOWN);
      expect(await c.cooldownPeriod()).to.equal(MIN_COOLDOWN);
    });
  });

  // ─── Core: First Renewal ───────────────────────────────────────────────────

  describe("First renewal attempt", function () {
    it("succeeds on first attempt (no previous timestamp)", async function () {
      await expect(contract.connect(alice).attemptRenewal())
        .to.emit(contract, "RenewalAttempted")
        .withArgs(alice.address, await time.latest() + 1 /* next block */);
    });

    it("records lastAttemptTimestamp after first attempt", async function () {
      await contract.connect(alice).attemptRenewal();
      const ts = await time.latest();
      const next = await contract.nextRenewalTimestamp(alice.address);
      expect(next).to.equal(ts + COOLDOWN);
    });

    it("marks subscriber as active", async function () {
      // Access via isInCooldown as a proxy for state being written
      await contract.connect(alice).attemptRenewal();
      expect(await contract.isInCooldown(alice.address)).to.equal(true);
    });
  });

  // ─── Core: Cooldown Enforcement ───────────────────────────────────────────

  describe("Second attempt within cooldown", function () {
    it("reverts immediately after first attempt", async function () {
      await contract.connect(alice).attemptRenewal();
      const lastTs = await time.latest();
      const retryAfter = lastTs + COOLDOWN;

      await expect(contract.connect(alice).attemptRenewal())
        .to.be.revertedWithCustomError(contract, "CooldownNotElapsed")
        .withArgs(retryAfter);
    });

    it("reverts 1 second before cooldown expires", async function () {
      await contract.connect(alice).attemptRenewal();
      await time.increase(COOLDOWN - 1);

      await expect(contract.connect(alice).attemptRenewal())
        .to.be.revertedWithCustomError(contract, "CooldownNotElapsed");
    });

    it("reverts exactly at cooldown boundary (strict >)", async function () {
      // block.timestamp == last + cooldown should still revert (need strictly >)
      await contract.connect(alice).attemptRenewal();
      await time.increase(COOLDOWN); // now block.timestamp == last + cooldown

      // The condition: now48 <= last + period  → REVERT at equality
      await expect(contract.connect(alice).attemptRenewal())
        .to.be.revertedWithCustomError(contract, "CooldownNotElapsed");
    });
  });

  // ─── Core: Attempt After Cooldown ─────────────────────────────────────────

  describe("Attempt after cooldown expires", function () {
    it("succeeds 1 second after cooldown boundary (COOLDOWN + 1)", async function () {
      await contract.connect(alice).attemptRenewal();
      await time.increase(COOLDOWN + 1);

      await expect(contract.connect(alice).attemptRenewal())
        .to.emit(contract, "RenewalAttempted");
    });

    it("resets the cooldown after successful re-attempt", async function () {
      await contract.connect(alice).attemptRenewal();
      await time.increase(COOLDOWN + 1);
      await contract.connect(alice).attemptRenewal();

      // Now should be in cooldown again
      expect(await contract.isInCooldown(alice.address)).to.equal(true);
      await expect(contract.connect(alice).attemptRenewal())
        .to.be.revertedWithCustomError(contract, "CooldownNotElapsed");
    });
  });

  // ─── Per-User Isolation ───────────────────────────────────────────────────

  describe("Per-user isolation (DoS resistance)", function () {
    it("alice's cooldown does not affect bob", async function () {
      await contract.connect(alice).attemptRenewal();

      // Bob has no cooldown — should succeed immediately
      await expect(contract.connect(bob).attemptRenewal())
        .to.emit(contract, "RenewalAttempted");
    });

    it("bob's spam does not affect alice's ability to renew", async function () {
      // Bob attempts once
      await contract.connect(bob).attemptRenewal();

      // Alice has never attempted — should succeed
      await expect(contract.connect(alice).attemptRenewal())
        .to.emit(contract, "RenewalAttempted");
    });
  });

  // ─── Admin: setCooldownPeriod ──────────────────────────────────────────────

  describe("setCooldownPeriod", function () {
    it("owner can update cooldown period", async function () {
      const newPeriod = 600;
      await expect(contract.connect(owner).setCooldownPeriod(newPeriod))
        .to.emit(contract, "CooldownPeriodUpdated")
        .withArgs(COOLDOWN, newPeriod);

      expect(await contract.cooldownPeriod()).to.equal(newPeriod);
    });

    it("non-owner cannot update cooldown period", async function () {
      await expect(contract.connect(alice).setCooldownPeriod(600))
        .to.be.revertedWithCustomError(contract, "Unauthorized");
    });

    it("reverts if new period is below MIN_COOLDOWN", async function () {
      await expect(contract.connect(owner).setCooldownPeriod(59))
        .to.be.revertedWithCustomError(contract, "InvalidCooldownPeriod")
        .withArgs(59, MIN_COOLDOWN);
    });

    it("new cooldown applies immediately to future attempts", async function () {
      // Reduce cooldown to 60s
      await contract.connect(owner).setCooldownPeriod(60);
      await contract.connect(alice).attemptRenewal();

      // Advancing 61s should now suffice
      await time.increase(61);
      await expect(contract.connect(alice).attemptRenewal())
        .to.emit(contract, "RenewalAttempted");
    });
  });

  // ─── View Functions ───────────────────────────────────────────────────────

  describe("View functions", function () {
    it("nextRenewalTimestamp returns 0 for new subscriber", async function () {
      expect(await contract.nextRenewalTimestamp(alice.address)).to.equal(0);
    });

    it("nextRenewalTimestamp returns correct value after attempt", async function () {
      await contract.connect(alice).attemptRenewal();
      const ts = await time.latest();
      expect(await contract.nextRenewalTimestamp(alice.address)).to.equal(ts + COOLDOWN);
    });

    it("isInCooldown returns false for new subscriber", async function () {
      expect(await contract.isInCooldown(alice.address)).to.equal(false);
    });

    it("isInCooldown returns true immediately after attempt", async function () {
      await contract.connect(alice).attemptRenewal();
      expect(await contract.isInCooldown(alice.address)).to.equal(true);
    });

    it("isInCooldown returns false after cooldown expires", async function () {
      await contract.connect(alice).attemptRenewal();
      await time.increase(COOLDOWN + 1);
      expect(await contract.isInCooldown(alice.address)).to.equal(false);
    });
  });

  // ─── Edge Cases ───────────────────────────────────────────────────────────

  describe("Edge cases", function () {
    it("handles uint48 overflow boundary safely (far future timestamp)", async function () {
      // uint48 max = 281474976710655 (~year 8.9M). Not a realistic concern,
      // but verify our cast doesn't silently wrap in current epoch.
      // Current block.timestamp << uint48 max — safe.
      const ts = await time.latest();
      expect(ts).to.be.lt(2n ** 48n);
    });

    it("multiple renewals over time accumulate correctly", async function () {
      for (let i = 0; i < 3; i++) {
        await contract.connect(alice).attemptRenewal();
        await time.increase(COOLDOWN + 1);
      }
      // 4th attempt should still work
      await expect(contract.connect(alice).attemptRenewal())
        .to.emit(contract, "RenewalAttempted");
    });

    it("zero address has no special privilege", async function () {
      // Just verify we don't accidentally allow address(0) to reset others
      expect(await contract.nextRenewalTimestamp(ethers.ZeroAddress)).to.equal(0);
    });
  });
});
